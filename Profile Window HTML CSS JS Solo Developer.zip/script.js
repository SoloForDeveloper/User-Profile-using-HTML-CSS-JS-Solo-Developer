//profile info
const details=[
    {
        id:1,
        name:"Anna James",
        job:"Lecturer",
        img:"dp1.jpg",
        text:"Hi' I'm a lecturer who is working at university and I like to share my knowledge with everyone.",
    },
    {
        id:2,
        name:"Solo Developer",
        job:"Web Developer",
        img:"dp2.png",
        text:"Hi' I'm a Web Developer who is working at university and I like to share my knowledge with everyone.",
    },
    {
        id:3,
        name:"Jack David",
        job:"Software Engineer",
        img:"dp1.jpg",
        text:"Hi' I'm a lecturer who is working at university and I like to share my knowledge with everyone.",
    },
    {
        id:4,
        name:"Margrate Pere",
        job:"Freelancer",
        img:"dp2.png",
        text:"Hi' I'm a Web Developer who is working at university and I like to share my knowledge with everyone.",
    }
];

//select elements
const img = document.getElementById("profile");
const author = document.getElementById("author");
const job = document.getElementById("job");
const info = document.getElementById("info");

const prevBtn = document.querySelector(".prev-btn");
const nextBtn = document.querySelector(".next-btn");
const randomBtn = document.querySelector(".random-btn");

let startingItem = 0;

function showPerson(person){
    const item = details[person];
    img.src= item.img;
    author.textContent = item.name;
    job.textContent = item.job;
    info.textContent = item.text;
}

nextBtn.addEventListener("click",function(){
    startingItem++;
    if(startingItem>details.length-1){
        startingItem=0;
    }
    showPerson(startingItem);
});

//prev button
prevBtn.addEventListener("click",function(){
    startingItem--;
    if(startingItem<0){
        startingItem=details.length-1;
    }
    showPerson(startingItem);
});

//random button
randomBtn.addEventListener("click",function(){
    startingItem = Math.floor(Math.random()*details.length);
    showPerson(startingItem);
});